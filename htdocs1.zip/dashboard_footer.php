
</div>









<!-- ไลน์ -->
<div class="linebtn">
    <img onclick="location.href='http://line.me/ti/p/~<?php echo $rowInfo['line_id']; ?>'" src="images/line/chat2.svg" width="70px">
</div>

<div class="myAlert-top alert">
<i class="fad fa-check-circle" style="color: #d2b882; font-size: 30px;"></i>
  <br>
  <strong style="color: white;">
    คัดลอกเรียบร้อย!  </strong>
</div>


























<!--     <footer class="footer mt-auto py-3">
  <div class="container">
    Place sticky footer content here.
  </div>
</footer> -->

    <div class="overlay"></div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
        <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script> -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>

    <!-- cdn flickity -->
    <script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>

    <!-- AOSJS -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

    <!-- swiper js -->
      <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

      <!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
      <!-- <script src="public/js/bootstrap.min.js"></script> -->
      <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.0-beta/js/bootstrap-select.min.js"></script> -->
			<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.js"></script> -->

    <script>
    AOS.init({once:true});
    </script>

</body>

</html>